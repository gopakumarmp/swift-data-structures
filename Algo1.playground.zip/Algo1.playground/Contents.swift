import UIKit

//reverse
var str = "Hello, playground"
var reverse = ""
for char in str {
    reverse  = char.description  + reverse
}
print(reverse)

// sort

var arr = ["Gopakumar", "Alex","Pujan","Mack","Merln","Bina","Jack","Cinjo","Vinod","Chugh"]

let sorted  = arr.sorted { (obj1, obj2) -> Bool in
    return obj1 < obj2
}
print(sorted)

//binary search

let sortedArray = ["1", "2","3","4","5","6","7","8","9","10"]
let key = "3"

var upperIndex = sortedArray.count
var lowerIndex = 0

while lowerIndex < upperIndex {
    let tem = Int(upperIndex) - Int(lowerIndex)
    var midIndex = lowerIndex + (tem)/2
    if sortedArray[midIndex] == key {
        print(sortedArray[midIndex])
        print(midIndex)
    }
    
    if key < sortedArray[midIndex] {
        upperIndex = (midIndex - 1)
    }else {
        lowerIndex = midIndex + 1
    }
}

//factorial
func factorial_recursive(_ factorialNumber: UInt64) -> UInt64 {
    if factorialNumber == 0 {
        return 1
    } else {
        return factorialNumber * factorial_recursive(factorialNumber - 1)
    }
}

// non rec factorial
print("Factorial is \(factorial_recursive(4))")


func factorial(_ factNum:UInt64) -> UInt64 {
    var num  = factNum
    var fact:UInt64 = 1
    if num == 0 {
        return 1
    } else {
        while num >= 1 {
            fact = fact * num
            print("fact:\(fact) * \(num)")
            num  = num - 1
        }
    }
    return fact
}

print("Factorial is \(factorial(4))")

//You are given two non-empty linked lists representing two non-negative integers. The digits are stored in reverse order and each of their nodes contain a single digit. Add the two numbers and return it as a linked list.
//
//You may assume the two numbers do not contain any leading zero, except the number 0 itself.
//
//Example:
//
//Input: (2 -> 4 -> 3) + (5 -> 6 -> 4)
//Output: 7 -> 0 -> 8
//Explanation: 342 + 465 = 807.


/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     public var val: Int
 *     public var next: ListNode?
 *     public init(_ val: Int) {
 *         self.val = val
 *         self.next = nil
 *     }
 * }
 */

//class ListNode {
//    var value:Int
//    var next:ListNode?
//}
//
//class Solution {
//    func addTwoNumbers(_ l1: ListNode?, _ l2: ListNode?) -> ListNode? {
//
//        var pow = 0
//        var fullNumeral = 0
//        var node  = l1
//        while node?.next !=  nil {
//            let item = node?.value
//            fullNumeral  +=
//            pow  = pow + 1
//        }
//
//
//        return ListNode
//    }
//}


