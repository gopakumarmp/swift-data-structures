import UIKit


// reverse
var str = "playground"
var reverse = ""

for char  in str {
    
    reverse = char.description + reverse
}
print(reverse)

//


